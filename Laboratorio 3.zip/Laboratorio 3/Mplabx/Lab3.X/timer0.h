/* 
 * File:   timer0.h
 * Author: galic
 *
 * Created on 12 de febrero de 2021, 04:46 PM
 */

#ifndef TIMER0_H
#define	TIMER0_H

#ifdef	__cplusplus
extern "C" {
#endif




#ifdef	__cplusplus
}
#endif

#endif	/* TIMER0_H */

