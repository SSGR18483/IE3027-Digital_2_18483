/* 
 * File:   confb.h
 * Author: galic
 *
 * Created on 12 de febrero de 2021, 04:59 PM
 */

#ifndef CONFB_H
#define	CONFB_H
#include <xc.h> // include processor files - each processor file is guarded. 

#endif	/* CONFB_H */

