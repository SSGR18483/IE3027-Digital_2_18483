/*
 * File:   SENSOR.c
 * Author: galic
 *
 * Created on 14 de marzo de 2021, 09:14 PM
 */


#include <avr/io.h>

int main(void) {
    /* Replace with your application code */
    while (1) {
    }
}
