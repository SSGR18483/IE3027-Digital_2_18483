/* 
 * File:   spis1.h
 * Author: galic
 *
 * Created on 23 de febrero de 2021, 06:22 PM
 */

#ifndef SPIS1_H
#define	SPIS1_H
#include <xc.h>

void spicon(void);

#endif	/* SPIS1_H */

