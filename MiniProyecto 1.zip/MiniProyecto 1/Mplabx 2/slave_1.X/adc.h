/* 
 * File:   adc.h
 * Author: galic
 *
 * Created on 22 de febrero de 2021, 03:44 PM
 */

#ifndef ADC_H
#define	ADC_H
#include <xc.h> 
void ADCONS(void);


#endif	/* ADC_H */

