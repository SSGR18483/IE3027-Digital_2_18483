/* 
 * File:   EUSCON.h
 * Author: galic
 *
 * Created on 14 de febrero de 2021, 09:22 PM
 */

#ifndef EUSCON_H
#define	EUSCON_H
#define _XTAL_FREQ 8000000

#include<xc.h>
#include<stdint.h>
#include <stdio.h>

void CONUSARTM(const long int baudrate);

#endif	/* EUSCON_H */

